# keyboards/__init__.py
from keyboards import user_kb, admin_kb

__all__ = ['user_kb', 'admin_kb']